
### Algorithms color:
library(RColorBrewer)

#alg.colors = brewer.pal(6, 'Set2')
#alg.colors.light = brewer.pal(6, 'Pastel2')

alg.colors = rainbow(6)
alg.colors.light = rainbow(6, s=0.4)

names(alg.colors) = c('lda', 'naiveBayes', 'knn', 'rpart', 'svm', 'nnet')
names(alg.colors.light) = c('lda', 'naiveBayes', 'knn', 'rpart', 'svm', 'nnet')
