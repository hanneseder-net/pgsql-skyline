###
### Visualisation of the bias of different learning algorithms. Idea
### from Vilalta and Drissi's paper: A Perspectiv View and Survey of Meta-Learning.
###
### $Id: fig-inductive-bias.R 270 2006-10-24 21:28:44Z manuel $
###


setwd('D:/Manuel/Projects/meta-learning/Papers/Master Thesis/plots/')



### Plot: ##########################################################################################

x11(width=4, height=1.5, pointsize=8)
par(mar=c(0.1, 0.1, 0.1, 0.1),    # c(bottom, left, top, right)
    mgp=c(0, 0, 0))               # c(axis title, axis labels, axis line)

plot(1:10, 1:10, type='n', xlab='', ylab='', axes=F)
text(1, 10, 'Universe of all classification problems:', adj=0)
rect(1, 1, 10, 9.5, lwd=0.5)

points(c(3, 5, 7, 2), c(8, 7, 3, 2), pch=19)
text(c(3, 5, 7, 2)+0.4, c(8, 7, 3, 2), c(expression(T[1]), expression(T[2]), expression(T[3]), expression(T[4])))

rect(2, 9, 6, 6, border=2)
rect(1.2, 9.3, 6.6, 5.5, border=2, lty=2)
text(7, 9, expression(l[1]), col=2)

rect(6, 2, 8, 4, border=3)
rect(4, 7.5, 9, 1.5, border=3, lty=2)
text(9.5, 7.3, expression(l[2]), col=3)

savePlot('fig-inductive-bias', type='eps')
savePlot('fig-inductive-bias', type='pdf')

dev.off()
