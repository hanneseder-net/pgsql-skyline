###
### Example for the task of classification: knn algorithm.
###
### $Id: fig-machine-learning-problems-classification.R 214 2006-09-27 19:44:36Z manuel $
###


setwd('D:/Manuel/Projects/meta-learning/Papers/Master Thesis/plots/')

library(class)
library(MASS)
library(rpart)

set.seed(999999)


### Data: ##########################################################################################

library(mvtnorm)

I = diag(c(1,1))

green.mks = rmvnorm(10, mean=t(c(1,0)), sigma=I)
red.mks = rmvnorm(10, mean=t(c(0,1)), sigma=I)

N = 100

green = matrix(NA, N, 3)
red = matrix(NA, N, 3)

for ( i in 1:N ) { 
  gi = sample(1:10, 1)
  ri = sample(1:10, 1)

  green[i,] = c(rmvnorm(1, mean=t(green.mks[gi,]), sigma=I/5), 1)
  red[i,] = c(rmvnorm(1, mean=(red.mks[ri,]), sigma=I/5), 0)
}


xrange = range(c(range(green[,1]), range(red[,1])))
xrange[1] = floor(xrange[1]); xrange[2] = ceiling(xrange[2])

yrange = range(c(range(green[,2]), range(red[,2])))
yrange[1] = floor(yrange[1]); yrange[2] = ceiling(yrange[2])

data = rbind(green, red)
colnames(data) = c('X', 'Y', 'Class')
data = data.frame(data)
data$Class = factor(data$Class)

data.grid = expand.grid(
  seq(xrange[1], xrange[2], by=0.05),
  seq(yrange[1], yrange[2], by=0.05))

data.grid = expand.grid(
  seq(xrange[1], xrange[2], by=0.2),
  seq(yrange[1], yrange[2], by=0.2))

colnames(data.grid) = c('X', 'Y')



### Methods: #######################################################################################

knn15.pred = knn(data[,-3], data.grid, cl=data[,3], k=15)
lda.pred = predict(lda(Class~X+Y, data), newdata=data.grid)$class
rpart.pred = predict(rpart(Class~X+Y, data), newdata=data.grid, type='class')



### Plots: #########################################################################################

x11(width=1.3, height=1.3, pointsize=8)
par(mar=c(.6, .6, 0.1, 0.1),      # c(bottom, left, top, right)
    mgp=c(0, 0, 0))               # c(axis title, axis labels, axis line)

plot(data[,-3], col=as.numeric(data[,3])+1, pch=19, xlab='', ylab='', xlim=xrange, ylim=yrange, axes=F)
axis(1, labels=NA, lwd=0.5)
axis(2, labels=NA, lwd=0.5)
box(lwd=0.5)

savePlot('fig-machine-learning-problems-classification', type='eps')
savePlot('fig-machine-learning-problems-classification', type='pdf')
dev.off()


x11(width=1.3, height=1.3, pointsize=8)
par(mar=c(.6, .6, 0.1, 0.1),      # c(bottom, left, top, right)
    mgp=c(0, 0, 0))               # c(axis title, axis labels, axis line)

plot(data[,-3], col=as.numeric(data[,3])+1, pch=19, xlab='', ylab='', xlim=xrange, ylim=yrange, axes=F)
axis(1, labels=NA, lwd=0.5)
axis(2, labels=NA, lwd=0.5)
box(lwd=0.5)

points(data.grid, pch='.', col=as.numeric(knn15.pred)+1)

savePlot('fig-machine-learning-problems-classification-knn15', type='eps')
savePlot('fig-machine-learning-problems-classification-knn15', type='pdf')
dev.off()


x11(width=1.3, height=1.3, pointsize=8)
par(mar=c(.6, .6, 0.1, 0.1),      # c(bottom, left, top, right)
    mgp=c(0, 0, 0))               # c(axis title, axis labels, axis line)

plot(data[,-3], col=as.numeric(data[,3])+1, pch=19, xlab='', ylab='', xlim=xrange, ylim=yrange, axes=F)
axis(1, labels=NA, lwd=0.5)
axis(2, labels=NA, lwd=0.5)
box(lwd=0.5)

points(data.grid, pch='.', col=as.numeric(lda.pred)+1)

savePlot('fig-machine-learning-problems-classification-lda', type='eps')
savePlot('fig-machine-learning-problems-classification-lda', type='pdf')
dev.off()


x11(width=1.3, height=1.3, pointsize=8)
par(mar=c(.6, .6, 0.1, 0.1),      # c(bottom, left, top, right)
    mgp=c(0, 0, 0))               # c(axis title, axis labels, axis line)

plot(data[,-3], col=as.numeric(data[,3])+1, pch=19, xlab='', ylab='', xlim=xrange, ylim=yrange, axes=F)
axis(1, labels=NA, lwd=0.5)
axis(2, labels=NA, lwd=0.5)
box(lwd=0.5)

points(data.grid, pch='.', col=as.numeric(rpart.pred)+1)

savePlot('fig-machine-learning-problems-classification-rpart', type='eps')
savePlot('fig-machine-learning-problems-classification-rpart', type='pdf')
dev.off()


