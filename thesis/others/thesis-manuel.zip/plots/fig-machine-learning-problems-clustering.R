###
### Example for the task of cluster analysis: kmeans algorithm.
###
### $Id: fig-machine-learning-problems-clustering.R 214 2006-09-27 19:44:36Z manuel $
###


setwd('D:/Manuel/Projects/meta-learning/Papers/Master Thesis/plots/')



### Data: ##########################################################################################

data = rbind(matrix(rnorm(100, sd = 0.3), ncol = 2), matrix(rnorm(100, mean = 1, sd = 0.3), ncol = 2))
colnames(data) = c('x', 'y')



### K-Means clustering: ############################################################################

kmeans5 = kmeans(data, 5, nstart = 25)



### Plots: #########################################################################################

x11(width=1.3, height=1.3, pointsize=8)
par(mar=c(.6, .6, 0.1, 0.1),      # c(bottom, left, top, right)
    mgp=c(0, 0, 0))               # c(axis title, axis labels, axis line)

plot(data[,1], data[,2], pch=19, xlab='', ylab='', axes=F)
axis(1, labels=NA, lwd=0.5)
axis(2, labels=NA, lwd=0.5)
box(lwd=0.5)

savePlot('fig-machine-learning-problems-clustering', type='eps')
savePlot('fig-machine-learning-problems-clustering', type='pdf')
dev.off()


x11(width=1.3, height=1.3, pointsize=8)
par(mar=c(.6, .6, 0.1, 0.1),      # c(bottom, left, top, right)
    mgp=c(0, 0, 0))               # c(axis title, axis labels, axis line)

plot(data[,1], data[,2], pch=19, col=kmeans5$cluster, xlab='', ylab='', axes=F)
axis(1, labels=NA, lwd=0.5)
axis(2, labels=NA, lwd=0.5)
box(lwd=0.5)

points(kmeans5$centers, col=1:5, pch=8)

savePlot('fig-machine-learning-problems-clustering-kmeans5', type='eps')
savePlot('fig-machine-learning-problems-clustering-kmeans5', type='pdf')
dev.off()
