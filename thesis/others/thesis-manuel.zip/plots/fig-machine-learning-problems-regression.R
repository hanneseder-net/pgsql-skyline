###
### Example for the task of regression: quadratic regression.
###
### $Id: fig-machine-learning-problems-regression.R 214 2006-09-27 19:44:36Z manuel $
###


setwd('D:/Manuel/Projects/meta-learning/Papers/Master Thesis/plots/')



### Data: ##########################################################################################

x = seq(-2, 2, length.out=50)
y = x^2 + rnorm(50,0,0.3)



### Quardratic regression model: ###################################################################

r = lm(y ~ I(x^2))



### Plots: #########################################################################################

x11(width=1.3, height=1.3, pointsize=8)
par(mar=c(.6, .6, 0.1, 0.1),      # c(bottom, left, top, right)
    mgp=c(0, 0, 0))               # c(axis title, axis labels, axis line)

plot(x, y, type='p', pch=19, xlab='', ylab='', axes=F)
axis(1, labels=NA, lwd=0.5)
axis(2, labels=NA, lwd=0.5)
box(lwd=0.5)

savePlot('fig-machine-learning-problems-regression', type='eps')
savePlot('fig-machine-learning-problems-regression', type='pdf')
dev.off()

x11(width=1.3, height=1.3, pointsize=8)
par(mar=c(.6, .6, 0.1, 0.1),      # c(bottom, left, top, right)
    mgp=c(0, 0, 0))               # c(axis title, axis labels, axis line)

plot(x, y, type='p', pch=19, xlab='', ylab='', axes=F)
axis(1, labels=NA, lwd=0.5)
axis(2, labels=NA, lwd=0.5)
box(lwd=0.5)

curve(predict(r, newdata=data.frame(x=x)), add=TRUE, col=2, lwd=1)

savePlot('fig-machine-learning-problems-regression-quadr', type='eps')
savePlot('fig-machine-learning-problems-regression-quadr', type='pdf')
dev.off()

