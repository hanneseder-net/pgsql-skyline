###
### Visualisation of the no-free-lunch theorem. Idea from
### http://en.wikipedia.org/wiki/No-free-lunch_theorem.
###
### $Id: fig-no-free-lunch.R 213 2006-09-27 07:12:31Z manuel $
###


setwd('D:/Manuel/Projects/meta-learning/Papers/Master Thesis/plots/')



xticks = 1:15
n = length(xticks)

yaverage = 1.5
yone = rnorm(n, mean=yaverage, sd=0.2)
ytwo = c(1, 1.1, 2, 6, 2, 1.1, 1.1, 1, 1.1, 1.1, 1.1, 1.1, 1, 1.1, 1.1)



### Plot: ##########################################################################################

x11(width=4, height=1.5, pointsize=8)
par(mar=c(2.1, 2.1, 0.1, 0.1),    # c(bottom, left, top, right)
    mgp=c(1, 0, 0))               # c(axis title, axis labels, axis line)

plot(xticks, rep(yaverage, n), type='l', lty=2, xlim=c(1,15), ylim=c(0,6.2),
     xlab='problems', ylab='performance', axes=F)
axis(1, labels=NA, lwd=0.5)
axis(2, labels=NA, lwd=0.5)
box(lwd=0.5)

lines(spline(xticks, yone, n=201), col=2, lwd=1)
lines(spline(xticks, ytwo, n=201), col=3, lwd=1)

par(lwd=0.5)    # because of the legend box
legend('topright', legend=c('average', 'general-purpose algorithm', 'specialized algorithm'),
       lwd=c(1,1,1), lty=c(2,1,1), col=c(1,2,3))
par(lwd=1)

savePlot('fig-no-free-lunch', type='eps')
savePlot('fig-no-free-lunch', type='pdf')

dev.off()
